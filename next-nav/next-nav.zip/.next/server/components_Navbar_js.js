exports.id = "components_Navbar_js";
exports.ids = ["components_Navbar_js"];
exports.modules = {

/***/ "./components/Navbar.js":
/*!******************************!*\
  !*** ./components/Navbar.js ***!
  \******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/Navbar.module.css */ "./styles/Navbar.module.css");
/* harmony import */ var _styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons */ "react-icons");
/* harmony import */ var react_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _NavbarData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./NavbarData */ "./components/NavbarData.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);


var _jsxFileName = "D:\\Code_Practice\\NextJS_Navbar\\next-nav\\components\\Navbar.js";








function Navbar({
  children
}) {
  const {
    0: navbar,
    1: setnavbar
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);

  const shownavbar = () => setnavbar(!navbar);

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_icons__WEBPACK_IMPORTED_MODULE_2__.IconContext.Provider, {
      value: {
        color: '#fff'
      },
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmain),
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navbar),
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
            href: "#",
            className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubar),
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
                src: "/menu.svg",
                className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubutton),
                onClick: shownavbar
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 23,
                columnNumber: 11
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 21,
              columnNumber: 9
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 20,
            columnNumber: 9
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 7
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().fullnav),
          children: _NavbarData__WEBPACK_IMPORTED_MODULE_3__.NavbarData.map((item, index) => {
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
              href: item.path,
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                  className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().maintitle),
                  children: item.title
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 33,
                  columnNumber: 11
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 31,
                columnNumber: 32
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 31,
              columnNumber: 9
            }, this);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 7
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 5
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("nav", {
        className: navbar ? `${(_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenu)} ${(_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().active)}` : (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenu),
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
          className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenuitems),
          onClick: shownavbar,
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
            className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().nabvartoggle),
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
              href: "#",
              className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubar),
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
                  src: "/close.svg",
                  className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().closebutton)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 45,
                  columnNumber: 13
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 44,
                columnNumber: 56
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 44,
              columnNumber: 11
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 9
          }, this), _NavbarData__WEBPACK_IMPORTED_MODULE_3__.NavbarData.map((item, index) => {
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
              className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navtext),
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                href: item.path,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                  children: [item.icon, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                    className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().title),
                    children: item.title
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 56,
                    columnNumber: 13
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 54,
                  columnNumber: 34
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 54,
                columnNumber: 11
              }, this)
            }, index, false, {
              fileName: _jsxFileName,
              lineNumber: 53,
              columnNumber: 9
            }, this);
          })]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 7
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 5
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 3
    }, this)
  }, void 0, false);
}

/* harmony default export */ __webpack_exports__["default"] = (Navbar);

/***/ }),

/***/ "./components/NavbarData.js":
/*!**********************************!*\
  !*** ./components/NavbarData.js ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavbarData": function() { return /* binding */ NavbarData; }
/* harmony export */ });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons/fa */ "./node_modules/react-icons/fa/index.esm.js");
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-icons/ai */ "./node_modules/react-icons/ai/index.esm.js");
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons/io */ "./node_modules/react-icons/io/index.esm.js");

var _jsxFileName = "D:\\Code_Practice\\NextJS_Navbar\\next-nav\\components\\NavbarData.js";



const NavbarData = [{
  title: 'Home',
  path: '/',
  icon: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_icons_ai__WEBPACK_IMPORTED_MODULE_1__.AiFillHome, {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 11
  }, undefined)
}, {
  title: 'Reports',
  path: '/Reports',
  icon: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_icons_io__WEBPACK_IMPORTED_MODULE_2__.IoIosPaper, {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 11
  }, undefined)
}, {
  title: 'Products',
  path: '/Products',
  icon: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__.FaCartPlus, {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 19,
    columnNumber: 11
  }, undefined)
}];

/***/ }),

/***/ "./styles/Navbar.module.css":
/*!**********************************!*\
  !*** ./styles/Navbar.module.css ***!
  \**********************************/
/***/ (function(module) {

// Exports
module.exports = {
	"navbar": "Navbar_navbar__3KWoz",
	"menubar": "Navbar_menubar__1_iED",
	"navmenu": "Navbar_navmenu__1j4Hb",
	"active": "Navbar_active__2UOQa",
	"navtext": "Navbar_navtext__36-_U",
	"navmenuitems": "Navbar_navmenuitems__3BAWg",
	"navbartoggle": "Navbar_navbartoggle__2-mOR",
	"title": "Navbar_title__16ROT",
	"menubutton": "Navbar_menubutton__2QhGr",
	"closebutton": "Navbar_closebutton__129kw",
	"navmain": "Navbar_navmain__3-YNy",
	"fullnav": "Navbar_fullnav__1aTN0"
};


/***/ }),

/***/ "?ca47":
/*!******************************************!*\
  !*** ./utils/resolve-rewrites (ignored) ***!
  \******************************************/
/***/ (function() {

/* (ignored) */

/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9uZXh0LW5hdi8uL2NvbXBvbmVudHMvTmF2YmFyLmpzIiwid2VicGFjazovL25leHQtbmF2Ly4vY29tcG9uZW50cy9OYXZiYXJEYXRhLmpzIiwid2VicGFjazovL25leHQtbmF2Ly4vc3R5bGVzL05hdmJhci5tb2R1bGUuY3NzIiwid2VicGFjazovL25leHQtbmF2L2lnbm9yZWR8RDpcXENvZGVfUHJhY3RpY2VcXE5leHRKU19OYXZiYXJcXG5leHQtbmF2XFxub2RlX21vZHVsZXNcXG5leHRcXGRpc3RcXG5leHQtc2VydmVyXFxsaWJcXHJvdXRlcnwuL3V0aWxzL3Jlc29sdmUtcmV3cml0ZXMiXSwibmFtZXMiOlsiTmF2YmFyIiwiY2hpbGRyZW4iLCJuYXZiYXIiLCJzZXRuYXZiYXIiLCJ1c2VTdGF0ZSIsInNob3duYXZiYXIiLCJjb2xvciIsIm5hdnN0eWxlcyIsIk5hdmJhckRhdGEiLCJpdGVtIiwiaW5kZXgiLCJwYXRoIiwidGl0bGUiLCJjbG9zZWJ1dHRvbiIsImljb24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBR0EsU0FBU0EsTUFBVCxDQUFnQjtBQUFDQztBQUFELENBQWhCLEVBQTRCO0FBQzVCLFFBQU07QUFBQSxPQUFDQyxNQUFEO0FBQUEsT0FBU0M7QUFBVCxNQUFzQkMsK0NBQVEsQ0FBQyxLQUFELENBQXBDOztBQUVBLFFBQU1DLFVBQVUsR0FBRyxNQUFNRixTQUFTLENBQUMsQ0FBQ0QsTUFBRixDQUFsQzs7QUFFQSxzQkFDQTtBQUFBLDJCQUNFLDhEQUFDLDZEQUFEO0FBQXNCLFdBQUssRUFBRTtBQUFFSSxhQUFLLEVBQUU7QUFBVCxPQUE3QjtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBRUMsMEVBQWhCO0FBQUEsZ0NBQ0U7QUFBSyxtQkFBUyxFQUFFQSx5RUFBaEI7QUFBQSxpQ0FDRSw4REFBQyxrREFBRDtBQUFNLGdCQUFJLEVBQUMsR0FBWDtBQUFlLHFCQUFTLEVBQUVBLDBFQUExQjtBQUFBLG1DQUNBO0FBQUEscUNBRUU7QUFBSyxtQkFBRyxFQUFDLFdBQVQ7QUFBcUIseUJBQVMsRUFBRUEsNkVBQWhDO0FBQXNELHVCQUFPLEVBQUVGO0FBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREYsZUFTRTtBQUFLLG1CQUFTLEVBQUVFLDBFQUFoQjtBQUFBLG9CQUNHQyx1REFBQSxDQUFlLENBQUNDLElBQUQsRUFBT0MsS0FBUCxLQUFpQjtBQUNqQyxnQ0FFQSw4REFBQyxrREFBRDtBQUFNLGtCQUFJLEVBQUVELElBQUksQ0FBQ0UsSUFBakI7QUFBQSxxQ0FBdUI7QUFBQSx1Q0FFckI7QUFBTSwyQkFBUyxFQUFFSiw0RUFBakI7QUFBQSw0QkFBdUNFLElBQUksQ0FBQ0c7QUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRkE7QUFRQyxXQVRBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQXdCRTtBQUFLLGlCQUFTLEVBQUVWLE1BQU0sR0FBSSxHQUFFSywwRUFBa0IsSUFBR0EseUVBQWlCLEVBQTVDLEdBQWdEQSwwRUFBdEU7QUFBQSwrQkFDRTtBQUFJLG1CQUFTLEVBQUVBLCtFQUFmO0FBQXVDLGlCQUFPLEVBQUVGLFVBQWhEO0FBQUEsa0NBQ0U7QUFBSSxxQkFBUyxFQUFFRSwrRUFBZjtBQUFBLG1DQUNFLDhEQUFDLGtEQUFEO0FBQU0sa0JBQUksRUFBQyxHQUFYO0FBQWUsdUJBQVMsRUFBRUEsMEVBQTFCO0FBQUEscUNBQTZDO0FBQUEsdUNBQzNDO0FBQUsscUJBQUcsRUFBQyxZQUFUO0FBQXNCLDJCQUFTLEVBQUVBLDhFQUFxQk07QUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUQyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLEVBU0dMLHVEQUFBLENBQWUsQ0FBQ0MsSUFBRCxFQUFPQyxLQUFQLEtBQWlCO0FBQ2pDLGdDQUNBO0FBQWdCLHVCQUFTLEVBQUVILDBFQUEzQjtBQUFBLHFDQUNFLDhEQUFDLGtEQUFEO0FBQU0sb0JBQUksRUFBRUUsSUFBSSxDQUFDRSxJQUFqQjtBQUFBLHVDQUF1QjtBQUFBLDZCQUNwQkYsSUFBSSxDQUFDSyxJQURlLGVBRXJCO0FBQU0sNkJBQVMsRUFBRVAsd0VBQWpCO0FBQUEsOEJBQW1DRSxJQUFJLENBQUNHO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBRnFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsZUFBU0YsS0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURBO0FBUUMsV0FUQSxDQVRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsbUJBREE7QUFtREM7O0FBRUQsK0RBQWVWLE1BQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25FQTtBQUNBO0FBQ0E7QUFFTyxNQUFNUSxVQUFVLEdBQUcsQ0FDeEI7QUFDRUksT0FBSyxFQUFFLE1BRFQ7QUFFRUQsTUFBSSxFQUFFLEdBRlI7QUFHRUcsTUFBSSxlQUFFLDhEQUFDLHNEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIUixDQUR3QixFQU14QjtBQUNFRixPQUFLLEVBQUUsU0FEVDtBQUVFRCxNQUFJLEVBQUUsVUFGUjtBQUdFRyxNQUFJLGVBQUUsOERBQUMsc0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhSLENBTndCLEVBV3hCO0FBQ0VGLE9BQUssRUFBRSxVQURUO0FBRUVELE1BQUksRUFBRSxXQUZSO0FBR0VHLE1BQUksZUFBRSw4REFBQyxzREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsQ0FYd0IsQ0FBbkIsQzs7Ozs7Ozs7OztBQ0pQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNkQSxlIiwiZmlsZSI6ImNvbXBvbmVudHNfTmF2YmFyX2pzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG5hdnN0eWxlcyBmcm9tICcuLi9zdHlsZXMvTmF2YmFyLm1vZHVsZS5jc3MnO1xyXG5pbXBvcnQgKiBhcyBGYUljb25zIGZyb20gJ3JlYWN0LWljb25zL2ZhJztcclxuaW1wb3J0ICogYXMgQWlJY29ucyBmcm9tICdyZWFjdC1pY29ucy9haSc7XHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBJY29uQ29udGV4dCB9IGZyb20gJ3JlYWN0LWljb25zJztcclxuaW1wb3J0IHsgTmF2YmFyRGF0YSB9IGZyb20gJy4vTmF2YmFyRGF0YSc7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuXHJcblxyXG5mdW5jdGlvbiBOYXZiYXIoe2NoaWxkcmVufSkge1xyXG5jb25zdCBbbmF2YmFyLCBzZXRuYXZiYXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuY29uc3Qgc2hvd25hdmJhciA9ICgpID0+IHNldG5hdmJhcighbmF2YmFyKTtcclxuXHJcbnJldHVybiAoXHJcbjw+XHJcbiAgPEljb25Db250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IGNvbG9yOiAnI2ZmZicgfX0+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17bmF2c3R5bGVzLm5hdm1haW59PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17bmF2c3R5bGVzLm5hdmJhcn0+XHJcbiAgICAgICAgPExpbmsgaHJlZj0nIycgY2xhc3NOYW1lPXtuYXZzdHlsZXMubWVudWJhcn0+XHJcbiAgICAgICAgPGE+XHJcblxyXG4gICAgICAgICAgPGltZyBzcmM9Jy9tZW51LnN2ZycgY2xhc3NOYW1lPXtuYXZzdHlsZXMubWVudWJ1dHRvbn0gb25DbGljaz17c2hvd25hdmJhcn0gLz5cclxuICAgICAgICA8L2E+XHJcbiAgICAgICAgPC9MaW5rPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e25hdnN0eWxlcy5mdWxsbmF2fT5cclxuICAgICAgICB7TmF2YmFyRGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIChcclxuXHJcbiAgICAgICAgPExpbmsgaHJlZj17aXRlbS5wYXRofT48YT5cclxuXHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e25hdnN0eWxlcy5tYWludGl0bGV9PntpdGVtLnRpdGxlfTwvc3Bhbj48L2E+XHJcbiAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICApO1xyXG4gICAgICAgIH0pfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG5cclxuICAgIDxuYXYgY2xhc3NOYW1lPXtuYXZiYXIgPyBgJHtuYXZzdHlsZXMubmF2bWVudX0gJHtuYXZzdHlsZXMuYWN0aXZlfWAgOiBuYXZzdHlsZXMubmF2bWVudX0+XHJcbiAgICAgIDx1bCBjbGFzc05hbWU9e25hdnN0eWxlcy5uYXZtZW51aXRlbXN9IG9uQ2xpY2s9e3Nob3duYXZiYXJ9PlxyXG4gICAgICAgIDxsaSBjbGFzc05hbWU9e25hdnN0eWxlcy5uYWJ2YXJ0b2dnbGV9PlxyXG4gICAgICAgICAgPExpbmsgaHJlZj0nIycgY2xhc3NOYW1lPXtuYXZzdHlsZXMubWVudWJhcn0+PGE+XHJcbiAgICAgICAgICAgIDxpbWcgc3JjPScvY2xvc2Uuc3ZnJyBjbGFzc05hbWU9e25hdnN0eWxlcy5jbG9zZWJ1dHRvbn0gLz5cclxuICAgICAgICAgICAgey8qXHJcbiAgICAgICAgICAgIDxBaUljb25zLkFpT3V0bGluZUNsb3NlIC8+ICovfVxyXG4gICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvbGk+XHJcbiAgICAgICAge05hdmJhckRhdGEubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPGxpIGtleT17aW5kZXh9IGNsYXNzTmFtZT17bmF2c3R5bGVzLm5hdnRleHR9PlxyXG4gICAgICAgICAgPExpbmsgaHJlZj17aXRlbS5wYXRofT48YT5cclxuICAgICAgICAgICAge2l0ZW0uaWNvbn1cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtuYXZzdHlsZXMudGl0bGV9PntpdGVtLnRpdGxlfTwvc3Bhbj48L2E+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9saT5cclxuICAgICAgICApO1xyXG4gICAgICAgIH0pfVxyXG4gICAgICA8L3VsPlxyXG4gICAgPC9uYXY+XHJcbiAgPC9JY29uQ29udGV4dC5Qcm92aWRlcj5cclxuPC8+XHJcbik7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE5hdmJhcjsiLCJpbXBvcnQgKiBhcyBGYUljb25zIGZyb20gJ3JlYWN0LWljb25zL2ZhJztcclxuaW1wb3J0ICogYXMgQWlJY29ucyBmcm9tICdyZWFjdC1pY29ucy9haSc7XHJcbmltcG9ydCAqIGFzIElvSWNvbnMgZnJvbSAncmVhY3QtaWNvbnMvaW8nO1xyXG5cclxuZXhwb3J0IGNvbnN0IE5hdmJhckRhdGEgPSBbXHJcbiAge1xyXG4gICAgdGl0bGU6ICdIb21lJyxcclxuICAgIHBhdGg6ICcvJyxcclxuICAgIGljb246IDxBaUljb25zLkFpRmlsbEhvbWUgLz5cclxuICB9LFxyXG4gIHtcclxuICAgIHRpdGxlOiAnUmVwb3J0cycsXHJcbiAgICBwYXRoOiAnL1JlcG9ydHMnLFxyXG4gICAgaWNvbjogPElvSWNvbnMuSW9Jb3NQYXBlciAvPlxyXG4gIH0sXHJcbiAge1xyXG4gICAgdGl0bGU6ICdQcm9kdWN0cycsXHJcbiAgICBwYXRoOiAnL1Byb2R1Y3RzJyxcclxuICAgIGljb246IDxGYUljb25zLkZhQ2FydFBsdXMgLz5cclxuICB9LFxyXG4gIFxyXG5dO1xyXG4iLCIvLyBFeHBvcnRzXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0XCJuYXZiYXJcIjogXCJOYXZiYXJfbmF2YmFyX18zS1dvelwiLFxuXHRcIm1lbnViYXJcIjogXCJOYXZiYXJfbWVudWJhcl9fMV9pRURcIixcblx0XCJuYXZtZW51XCI6IFwiTmF2YmFyX25hdm1lbnVfXzFqNEhiXCIsXG5cdFwiYWN0aXZlXCI6IFwiTmF2YmFyX2FjdGl2ZV9fMlVPUWFcIixcblx0XCJuYXZ0ZXh0XCI6IFwiTmF2YmFyX25hdnRleHRfXzM2LV9VXCIsXG5cdFwibmF2bWVudWl0ZW1zXCI6IFwiTmF2YmFyX25hdm1lbnVpdGVtc19fM0JBV2dcIixcblx0XCJuYXZiYXJ0b2dnbGVcIjogXCJOYXZiYXJfbmF2YmFydG9nZ2xlX18yLW1PUlwiLFxuXHRcInRpdGxlXCI6IFwiTmF2YmFyX3RpdGxlX18xNlJPVFwiLFxuXHRcIm1lbnVidXR0b25cIjogXCJOYXZiYXJfbWVudWJ1dHRvbl9fMlFoR3JcIixcblx0XCJjbG9zZWJ1dHRvblwiOiBcIk5hdmJhcl9jbG9zZWJ1dHRvbl9fMTI5a3dcIixcblx0XCJuYXZtYWluXCI6IFwiTmF2YmFyX25hdm1haW5fXzMtWU55XCIsXG5cdFwiZnVsbG5hdlwiOiBcIk5hdmJhcl9mdWxsbmF2X18xYVROMFwiXG59O1xuIiwiLyogKGlnbm9yZWQpICovIl0sInNvdXJjZVJvb3QiOiIifQ==