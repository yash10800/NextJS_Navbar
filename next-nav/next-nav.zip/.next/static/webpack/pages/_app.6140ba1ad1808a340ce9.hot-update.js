self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./components/Navbar.js":
/*!******************************!*\
  !*** ./components/Navbar.js ***!
  \******************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/Navbar.module.css */ "./styles/Navbar.module.css");
/* harmony import */ var _styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons */ "./node_modules/react-icons/lib/esm/index.js");
/* harmony import */ var _NavbarData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./NavbarData */ "./components/NavbarData.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "D:\\Code_Practice\\NextJS_Navbar\\next-nav\\components\\Navbar.js",
    _s = $RefreshSig$();









function Navbar(_ref) {
  _s();

  var _this = this;

  var children = _ref.children;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false),
      navbar = _useState[0],
      setnavbar = _useState[1];

  var shownavbar = function shownavbar() {
    return setnavbar(!navbar);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_icons__WEBPACK_IMPORTED_MODULE_2__.IconContext.Provider, {
      value: {
        color: '#fff'
      },
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmain)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 11
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("nav", {
        className: navbar ? "".concat((_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenu), " ").concat((_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().active)) : (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenu),
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
          className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenuitems),
          onClick: shownavbar,
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
            className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().nabvartoggle),
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
              href: "#",
              className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubar),
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
                  src: "/close.svg",
                  className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().closebutton)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 26,
                  columnNumber: 17
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 25,
                columnNumber: 62
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 25,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 24,
            columnNumber: 15
          }, this), _NavbarData__WEBPACK_IMPORTED_MODULE_3__.NavbarData.map(function (item, index) {
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
              className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navtext),
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                href: item.path,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                  children: [item.icon, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                    className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().title),
                    children: item.title
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 36,
                    columnNumber: 23
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 34,
                  columnNumber: 44
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 34,
                columnNumber: 21
              }, _this)
            }, index, false, {
              fileName: _jsxFileName,
              lineNumber: 33,
              columnNumber: 19
            }, _this);
          })]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 23,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 9
    }, this)
  }, void 0, false);
}

_s(Navbar, "hHN1UjZU2KVtXsET36Ln8CXJx+w=");

_c = Navbar;
/* harmony default export */ __webpack_exports__["default"] = (Navbar);

var _c;

$RefreshReg$(_c, "Navbar");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9OYXZiYXIuanMiXSwibmFtZXMiOlsiTmF2YmFyIiwiY2hpbGRyZW4iLCJ1c2VTdGF0ZSIsIm5hdmJhciIsInNldG5hdmJhciIsInNob3duYXZiYXIiLCJjb2xvciIsIm5hdnN0eWxlcyIsIm5hdm1haW4iLCJjbG9zZWJ1dHRvbiIsIk5hdmJhckRhdGEiLCJpdGVtIiwiaW5kZXgiLCJwYXRoIiwiaWNvbiIsInRpdGxlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQSxTQUFTQSxNQUFULE9BQTRCO0FBQUE7O0FBQUE7O0FBQUEsTUFBWEMsUUFBVyxRQUFYQSxRQUFXOztBQUFBLGtCQUNJQywrQ0FBUSxDQUFDLEtBQUQsQ0FEWjtBQUFBLE1BQ2pCQyxNQURpQjtBQUFBLE1BQ1RDLFNBRFM7O0FBR3hCLE1BQU1DLFVBQVUsR0FBRyxTQUFiQSxVQUFhO0FBQUEsV0FBTUQsU0FBUyxDQUFDLENBQUNELE1BQUYsQ0FBZjtBQUFBLEdBQW5COztBQUVBLHNCQUNFO0FBQUEsMkJBQ0UsOERBQUMsNkRBQUQ7QUFBc0IsV0FBSyxFQUFFO0FBQUVHLGFBQUssRUFBRTtBQUFULE9BQTdCO0FBQUEsOEJBQ0U7QUFBSyxpQkFBUyxFQUFFQywwRUFBaUJDO0FBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQUtFO0FBQUssaUJBQVMsRUFBRUwsTUFBTSxhQUFNSSwwRUFBTixjQUEyQkEseUVBQTNCLElBQWdEQSwwRUFBdEU7QUFBQSwrQkFDRTtBQUFJLG1CQUFTLEVBQUVBLCtFQUFmO0FBQXVDLGlCQUFPLEVBQUVGLFVBQWhEO0FBQUEsa0NBQ0U7QUFBSSxxQkFBUyxFQUFFRSwrRUFBZjtBQUFBLG1DQUNFLDhEQUFDLGtEQUFEO0FBQU0sa0JBQUksRUFBQyxHQUFYO0FBQWUsdUJBQVMsRUFBRUEsMEVBQTFCO0FBQUEscUNBQTZDO0FBQUEsdUNBQzdDO0FBQUsscUJBQUcsRUFBQyxZQUFUO0FBQXNCLDJCQUFTLEVBQUVBLDhFQUFxQkU7QUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUQ2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURGLEVBUUdDLHVEQUFBLENBQWUsVUFBQ0MsSUFBRCxFQUFPQyxLQUFQLEVBQWlCO0FBQy9CLGdDQUNFO0FBQWdCLHVCQUFTLEVBQUVMLDBFQUEzQjtBQUFBLHFDQUNFLDhEQUFDLGtEQUFEO0FBQU0sb0JBQUksRUFBRUksSUFBSSxDQUFDRSxJQUFqQjtBQUFBLHVDQUF1QjtBQUFBLDZCQUNwQkYsSUFBSSxDQUFDRyxJQURlLGVBRXJCO0FBQU0sNkJBQVMsRUFBRVAsd0VBQWpCO0FBQUEsOEJBQW1DSSxJQUFJLENBQUNJO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRnFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsZUFBU0gsS0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGO0FBUUQsV0FUQSxDQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFERjtBQStCRDs7R0FwQ01aLE07O0tBQUFBLE07QUFzQ1AsK0RBQWVBLE1BQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC42MTQwYmExYWQxODA4YTM0MGNlOS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG5hdnN0eWxlcyBmcm9tICcuLi9zdHlsZXMvTmF2YmFyLm1vZHVsZS5jc3MnO1xyXG5pbXBvcnQgKiBhcyBGYUljb25zIGZyb20gJ3JlYWN0LWljb25zL2ZhJztcclxuaW1wb3J0ICogYXMgQWlJY29ucyBmcm9tICdyZWFjdC1pY29ucy9haSc7XHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBJY29uQ29udGV4dCB9IGZyb20gJ3JlYWN0LWljb25zJztcclxuaW1wb3J0IHsgTmF2YmFyRGF0YSB9IGZyb20gJy4vTmF2YmFyRGF0YSc7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuXHJcblxyXG5mdW5jdGlvbiBOYXZiYXIoe2NoaWxkcmVufSkge1xyXG4gICAgY29uc3QgW25hdmJhciwgc2V0bmF2YmFyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBcclxuICAgIGNvbnN0IHNob3duYXZiYXIgPSAoKSA9PiBzZXRuYXZiYXIoIW5hdmJhcik7XHJcbiAgXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8PlxyXG4gICAgICAgIDxJY29uQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17eyBjb2xvcjogJyNmZmYnIH19PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e25hdnN0eWxlcy5uYXZtYWlufT5cclxuXHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPG5hdiBjbGFzc05hbWU9e25hdmJhciA/IGAke25hdnN0eWxlcy5uYXZtZW51fSAke25hdnN0eWxlcy5hY3RpdmV9YCA6IG5hdnN0eWxlcy5uYXZtZW51fT5cclxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT17bmF2c3R5bGVzLm5hdm1lbnVpdGVtc30gb25DbGljaz17c2hvd25hdmJhcn0+XHJcbiAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT17bmF2c3R5bGVzLm5hYnZhcnRvZ2dsZX0+XHJcbiAgICAgICAgICAgICAgICA8TGluayBocmVmPScjJyBjbGFzc05hbWU9e25hdnN0eWxlcy5tZW51YmFyfT48YT5cclxuICAgICAgICAgICAgICAgIDxpbWcgc3JjPScvY2xvc2Uuc3ZnJyBjbGFzc05hbWU9e25hdnN0eWxlcy5jbG9zZWJ1dHRvbn0vPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPEFpSWNvbnMuQWlPdXRsaW5lQ2xvc2UgLz4gKi99XHJcbiAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgIHtOYXZiYXJEYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2luZGV4fSBjbGFzc05hbWU9e25hdnN0eWxlcy5uYXZ0ZXh0fT5cclxuICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPXtpdGVtLnBhdGh9PjxhPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uaWNvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17bmF2c3R5bGVzLnRpdGxlfT57aXRlbS50aXRsZX08L3NwYW4+PC9hPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICA8L25hdj5cclxuICAgICAgICA8L0ljb25Db250ZXh0LlByb3ZpZGVyPlxyXG4gICAgICA8Lz5cclxuICAgICk7XHJcbiAgfVxyXG4gIFxyXG4gIGV4cG9ydCBkZWZhdWx0IE5hdmJhcjtcclxuICBcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==