self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./components/Navbar.js":
/*!******************************!*\
  !*** ./components/Navbar.js ***!
  \******************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/Navbar.module.css */ "./styles/Navbar.module.css");
/* harmony import */ var _styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons */ "./node_modules/react-icons/lib/esm/index.js");
/* harmony import */ var _NavbarData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./NavbarData */ "./components/NavbarData.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "D:\\Code_Practice\\NextJS_Navbar\\next-nav\\components\\Navbar.js",
    _s = $RefreshSig$();









function Navbar(_ref) {
  _s();

  var _this = this;

  var children = _ref.children;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false),
      navbar = _useState[0],
      setnavbar = _useState[1];

  var shownavbar = function shownavbar() {
    return setnavbar(!navbar);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_icons__WEBPACK_IMPORTED_MODULE_2__.IconContext.Provider, {
      value: {
        color: '#fff'
      },
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmain),
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navbar),
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
            href: "#",
            className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubar),
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
                src: "/menu.svg",
                className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubutton),
                onClick: shownavbar
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 23,
                columnNumber: 11
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 21,
              columnNumber: 9
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 20,
            columnNumber: 9
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 7
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
          className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().fullnav),
          children: _NavbarData__WEBPACK_IMPORTED_MODULE_3__.NavbarData.map(function (item, index) {
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
              href: item.path,
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                  className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().mtitle),
                  children: item.title
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 33,
                  columnNumber: 11
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 31,
                columnNumber: 32
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 31,
              columnNumber: 9
            }, _this);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 27,
          columnNumber: 7
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 5
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("nav", {
        className: navbar ? "".concat((_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenu), " ").concat((_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().active)) : (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenu),
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
          className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenuitems),
          onClick: shownavbar,
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
            className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().nabvartoggle),
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
              href: "#",
              className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubar),
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
                  src: "/close.svg",
                  className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().closebutton)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 45,
                  columnNumber: 13
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 44,
                columnNumber: 56
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 44,
              columnNumber: 11
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 9
          }, this), _NavbarData__WEBPACK_IMPORTED_MODULE_3__.NavbarData.map(function (item, index) {
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
              className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navtext),
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                href: item.path,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                  children: [item.icon, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                    className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().title),
                    children: item.title
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 56,
                    columnNumber: 13
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 54,
                  columnNumber: 34
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 54,
                columnNumber: 11
              }, _this)
            }, index, false, {
              fileName: _jsxFileName,
              lineNumber: 53,
              columnNumber: 9
            }, _this);
          })]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 7
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 5
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 3
    }, this)
  }, void 0, false);
}

_s(Navbar, "hHN1UjZU2KVtXsET36Ln8CXJx+w=");

_c = Navbar;
/* harmony default export */ __webpack_exports__["default"] = (Navbar);

var _c;

$RefreshReg$(_c, "Navbar");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9OYXZiYXIuanMiXSwibmFtZXMiOlsiTmF2YmFyIiwiY2hpbGRyZW4iLCJ1c2VTdGF0ZSIsIm5hdmJhciIsInNldG5hdmJhciIsInNob3duYXZiYXIiLCJjb2xvciIsIm5hdnN0eWxlcyIsIk5hdmJhckRhdGEiLCJpdGVtIiwiaW5kZXgiLCJwYXRoIiwidGl0bGUiLCJjbG9zZWJ1dHRvbiIsImljb24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBLFNBQVNBLE1BQVQsT0FBNEI7QUFBQTs7QUFBQTs7QUFBQSxNQUFYQyxRQUFXLFFBQVhBLFFBQVc7O0FBQUEsa0JBQ0FDLCtDQUFRLENBQUMsS0FBRCxDQURSO0FBQUEsTUFDckJDLE1BRHFCO0FBQUEsTUFDYkMsU0FEYTs7QUFHNUIsTUFBTUMsVUFBVSxHQUFHLFNBQWJBLFVBQWE7QUFBQSxXQUFNRCxTQUFTLENBQUMsQ0FBQ0QsTUFBRixDQUFmO0FBQUEsR0FBbkI7O0FBRUEsc0JBQ0E7QUFBQSwyQkFDRSw4REFBQyw2REFBRDtBQUFzQixXQUFLLEVBQUU7QUFBRUcsYUFBSyxFQUFFO0FBQVQsT0FBN0I7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUVDLDBFQUFoQjtBQUFBLGdDQUNFO0FBQUssbUJBQVMsRUFBRUEseUVBQWhCO0FBQUEsaUNBQ0UsOERBQUMsa0RBQUQ7QUFBTSxnQkFBSSxFQUFDLEdBQVg7QUFBZSxxQkFBUyxFQUFFQSwwRUFBMUI7QUFBQSxtQ0FDQTtBQUFBLHFDQUVFO0FBQUssbUJBQUcsRUFBQyxXQUFUO0FBQXFCLHlCQUFTLEVBQUVBLDZFQUFoQztBQUFzRCx1QkFBTyxFQUFFRjtBQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURGLGVBU0U7QUFBSyxtQkFBUyxFQUFFRSwwRUFBaEI7QUFBQSxvQkFDR0MsdURBQUEsQ0FBZSxVQUFDQyxJQUFELEVBQU9DLEtBQVAsRUFBaUI7QUFDakMsZ0NBRUEsOERBQUMsa0RBQUQ7QUFBTSxrQkFBSSxFQUFFRCxJQUFJLENBQUNFLElBQWpCO0FBQUEscUNBQXVCO0FBQUEsdUNBRXJCO0FBQU0sMkJBQVMsRUFBRUoseUVBQWpCO0FBQUEsNEJBQW9DRSxJQUFJLENBQUNHO0FBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGcUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZBO0FBUUMsV0FUQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUF3QkU7QUFBSyxpQkFBUyxFQUFFVCxNQUFNLGFBQU1JLDBFQUFOLGNBQTJCQSx5RUFBM0IsSUFBZ0RBLDBFQUF0RTtBQUFBLCtCQUNFO0FBQUksbUJBQVMsRUFBRUEsK0VBQWY7QUFBdUMsaUJBQU8sRUFBRUYsVUFBaEQ7QUFBQSxrQ0FDRTtBQUFJLHFCQUFTLEVBQUVFLCtFQUFmO0FBQUEsbUNBQ0UsOERBQUMsa0RBQUQ7QUFBTSxrQkFBSSxFQUFDLEdBQVg7QUFBZSx1QkFBUyxFQUFFQSwwRUFBMUI7QUFBQSxxQ0FBNkM7QUFBQSx1Q0FDM0M7QUFBSyxxQkFBRyxFQUFDLFlBQVQ7QUFBc0IsMkJBQVMsRUFBRUEsOEVBQXFCTTtBQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRDJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsRUFTR0wsdURBQUEsQ0FBZSxVQUFDQyxJQUFELEVBQU9DLEtBQVAsRUFBaUI7QUFDakMsZ0NBQ0E7QUFBZ0IsdUJBQVMsRUFBRUgsMEVBQTNCO0FBQUEscUNBQ0UsOERBQUMsa0RBQUQ7QUFBTSxvQkFBSSxFQUFFRSxJQUFJLENBQUNFLElBQWpCO0FBQUEsdUNBQXVCO0FBQUEsNkJBQ3BCRixJQUFJLENBQUNLLElBRGUsZUFFckI7QUFBTSw2QkFBUyxFQUFFUCx3RUFBakI7QUFBQSw4QkFBbUNFLElBQUksQ0FBQ0c7QUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGcUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixlQUFTRixLQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREE7QUFRQyxXQVRBLENBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFEQTtBQW1EQzs7R0F4RFFWLE07O0tBQUFBLE07QUEwRFQsK0RBQWVBLE1BQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguNDBjZmY5M2VlMTc2ZjdkYzZjZjguaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBuYXZzdHlsZXMgZnJvbSAnLi4vc3R5bGVzL05hdmJhci5tb2R1bGUuY3NzJztcclxuaW1wb3J0ICogYXMgRmFJY29ucyBmcm9tICdyZWFjdC1pY29ucy9mYSc7XHJcbmltcG9ydCAqIGFzIEFpSWNvbnMgZnJvbSAncmVhY3QtaWNvbnMvYWknO1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgSWNvbkNvbnRleHQgfSBmcm9tICdyZWFjdC1pY29ucyc7XHJcbmltcG9ydCB7IE5hdmJhckRhdGEgfSBmcm9tICcuL05hdmJhckRhdGEnO1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcblxyXG5cclxuZnVuY3Rpb24gTmF2YmFyKHtjaGlsZHJlbn0pIHtcclxuY29uc3QgW25hdmJhciwgc2V0bmF2YmFyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbmNvbnN0IHNob3duYXZiYXIgPSAoKSA9PiBzZXRuYXZiYXIoIW5hdmJhcik7XHJcblxyXG5yZXR1cm4gKFxyXG48PlxyXG4gIDxJY29uQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17eyBjb2xvcjogJyNmZmYnIH19PlxyXG4gICAgPGRpdiBjbGFzc05hbWU9e25hdnN0eWxlcy5uYXZtYWlufT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e25hdnN0eWxlcy5uYXZiYXJ9PlxyXG4gICAgICAgIDxMaW5rIGhyZWY9JyMnIGNsYXNzTmFtZT17bmF2c3R5bGVzLm1lbnViYXJ9PlxyXG4gICAgICAgIDxhPlxyXG5cclxuICAgICAgICAgIDxpbWcgc3JjPScvbWVudS5zdmcnIGNsYXNzTmFtZT17bmF2c3R5bGVzLm1lbnVidXR0b259IG9uQ2xpY2s9e3Nob3duYXZiYXJ9IC8+XHJcbiAgICAgICAgPC9hPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtuYXZzdHlsZXMuZnVsbG5hdn0+XHJcbiAgICAgICAge05hdmJhckRhdGEubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgIHJldHVybiAoXHJcblxyXG4gICAgICAgIDxMaW5rIGhyZWY9e2l0ZW0ucGF0aH0+PGE+XHJcblxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtuYXZzdHlsZXMubXRpdGxlfT57aXRlbS50aXRsZX08L3NwYW4+PC9hPlxyXG4gICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgKTtcclxuICAgICAgICB9KX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuXHJcbiAgICA8bmF2IGNsYXNzTmFtZT17bmF2YmFyID8gYCR7bmF2c3R5bGVzLm5hdm1lbnV9ICR7bmF2c3R5bGVzLmFjdGl2ZX1gIDogbmF2c3R5bGVzLm5hdm1lbnV9PlxyXG4gICAgICA8dWwgY2xhc3NOYW1lPXtuYXZzdHlsZXMubmF2bWVudWl0ZW1zfSBvbkNsaWNrPXtzaG93bmF2YmFyfT5cclxuICAgICAgICA8bGkgY2xhc3NOYW1lPXtuYXZzdHlsZXMubmFidmFydG9nZ2xlfT5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9JyMnIGNsYXNzTmFtZT17bmF2c3R5bGVzLm1lbnViYXJ9PjxhPlxyXG4gICAgICAgICAgICA8aW1nIHNyYz0nL2Nsb3NlLnN2ZycgY2xhc3NOYW1lPXtuYXZzdHlsZXMuY2xvc2VidXR0b259IC8+XHJcbiAgICAgICAgICAgIHsvKlxyXG4gICAgICAgICAgICA8QWlJY29ucy5BaU91dGxpbmVDbG9zZSAvPiAqL31cclxuICAgICAgICAgIDwvYT5cclxuICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICA8L2xpPlxyXG4gICAgICAgIHtOYXZiYXJEYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxsaSBrZXk9e2luZGV4fSBjbGFzc05hbWU9e25hdnN0eWxlcy5uYXZ0ZXh0fT5cclxuICAgICAgICAgIDxMaW5rIGhyZWY9e2l0ZW0ucGF0aH0+PGE+XHJcbiAgICAgICAgICAgIHtpdGVtLmljb259XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17bmF2c3R5bGVzLnRpdGxlfT57aXRlbS50aXRsZX08L3NwYW4+PC9hPlxyXG4gICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgIDwvbGk+XHJcbiAgICAgICAgKTtcclxuICAgICAgICB9KX1cclxuICAgICAgPC91bD5cclxuICAgIDwvbmF2PlxyXG4gIDwvSWNvbkNvbnRleHQuUHJvdmlkZXI+XHJcbjwvPlxyXG4pO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOYXZiYXI7Il0sInNvdXJjZVJvb3QiOiIifQ==