self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./components/Navbar.js":
/*!******************************!*\
  !*** ./components/Navbar.js ***!
  \******************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/Navbar.module.css */ "./styles/Navbar.module.css");
/* harmony import */ var _styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons */ "./node_modules/react-icons/lib/esm/index.js");
/* harmony import */ var _NavbarData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./NavbarData */ "./components/NavbarData.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "D:\\Code_Practice\\NextJS_Navbar\\next-nav\\components\\Navbar.js",
    _s = $RefreshSig$();









function Navbar(_ref) {
  _s();

  var _this = this;

  var children = _ref.children;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false),
      navbar = _useState[0],
      setnavbar = _useState[1];

  var shownavbar = function shownavbar() {
    return setnavbar(!navbar);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_icons__WEBPACK_IMPORTED_MODULE_2__.IconContext.Provider, {
      value: {
        color: '#fff'
      },
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navbar),
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
          href: "#",
          className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubar),
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
              src: "/menu.svg",
              className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubutton),
              onClick: shownavbar
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 20,
            columnNumber: 17
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 11
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "navs",
        children: _NavbarData__WEBPACK_IMPORTED_MODULE_3__.NavbarData.map(function (item, index) {
          return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
            href: item.path,
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
              children: [item.icon, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().title),
                children: item.title
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 32,
                columnNumber: 23
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 30,
              columnNumber: 44
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 30,
            columnNumber: 21
          }, _this);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 11
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("nav", {
        className: navbar ? "".concat((_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenu), " ").concat((_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().active)) : (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenu),
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
          className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenuitems),
          onClick: shownavbar,
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
            className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().nabvartoggle),
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
              href: "#",
              className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubar),
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
                  src: "/close.svg",
                  className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().closebutton)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 42,
                  columnNumber: 17
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 41,
                columnNumber: 62
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 41,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 40,
            columnNumber: 15
          }, this), _NavbarData__WEBPACK_IMPORTED_MODULE_3__.NavbarData.map(function (item, index) {
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
              className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navtext),
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                href: item.path,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                  children: [item.icon, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                    className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().title),
                    children: item.title
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 52,
                    columnNumber: 23
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 50,
                  columnNumber: 44
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 50,
                columnNumber: 21
              }, _this)
            }, index, false, {
              fileName: _jsxFileName,
              lineNumber: 49,
              columnNumber: 19
            }, _this);
          })]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 9
    }, this)
  }, void 0, false);
}

_s(Navbar, "hHN1UjZU2KVtXsET36Ln8CXJx+w=");

_c = Navbar;
/* harmony default export */ __webpack_exports__["default"] = (Navbar);

var _c;

$RefreshReg$(_c, "Navbar");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9OYXZiYXIuanMiXSwibmFtZXMiOlsiTmF2YmFyIiwiY2hpbGRyZW4iLCJ1c2VTdGF0ZSIsIm5hdmJhciIsInNldG5hdmJhciIsInNob3duYXZiYXIiLCJjb2xvciIsIm5hdnN0eWxlcyIsIk5hdmJhckRhdGEiLCJpdGVtIiwiaW5kZXgiLCJwYXRoIiwiaWNvbiIsInRpdGxlIiwiY2xvc2VidXR0b24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBLFNBQVNBLE1BQVQsT0FBNEI7QUFBQTs7QUFBQTs7QUFBQSxNQUFYQyxRQUFXLFFBQVhBLFFBQVc7O0FBQUEsa0JBQ0lDLCtDQUFRLENBQUMsS0FBRCxDQURaO0FBQUEsTUFDakJDLE1BRGlCO0FBQUEsTUFDVEMsU0FEUzs7QUFHeEIsTUFBTUMsVUFBVSxHQUFHLFNBQWJBLFVBQWE7QUFBQSxXQUFNRCxTQUFTLENBQUMsQ0FBQ0QsTUFBRixDQUFmO0FBQUEsR0FBbkI7O0FBRUEsc0JBQ0U7QUFBQSwyQkFDRSw4REFBQyw2REFBRDtBQUFzQixXQUFLLEVBQUU7QUFBRUcsYUFBSyxFQUFFO0FBQVQsT0FBN0I7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUVDLHlFQUFoQjtBQUFBLCtCQUNFLDhEQUFDLGtEQUFEO0FBQU0sY0FBSSxFQUFDLEdBQVg7QUFBZSxtQkFBUyxFQUFFQSwwRUFBMUI7QUFBQSxpQ0FDSTtBQUFBLG1DQUVGO0FBQUssaUJBQUcsRUFBQyxXQUFUO0FBQXFCLHVCQUFTLEVBQUVBLDZFQUFoQztBQUFzRCxxQkFBTyxFQUFFRjtBQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFTRTtBQUFLLGlCQUFTLEVBQUMsTUFBZjtBQUFBLGtCQUNDRyx1REFBQSxDQUFlLFVBQUNDLElBQUQsRUFBT0MsS0FBUCxFQUFpQjtBQUMzQiw4QkFFSSw4REFBQyxrREFBRDtBQUFNLGdCQUFJLEVBQUVELElBQUksQ0FBQ0UsSUFBakI7QUFBQSxtQ0FBdUI7QUFBQSx5QkFDcEJGLElBQUksQ0FBQ0csSUFEZSxlQUVyQjtBQUFNLHlCQUFTLEVBQUVMLHdFQUFqQjtBQUFBLDBCQUFtQ0UsSUFBSSxDQUFDSTtBQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGSjtBQVFELFNBVEo7QUFERDtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVEYsZUFxQkU7QUFBSyxpQkFBUyxFQUFFVixNQUFNLGFBQU1JLDBFQUFOLGNBQTJCQSx5RUFBM0IsSUFBZ0RBLDBFQUF0RTtBQUFBLCtCQUNFO0FBQUksbUJBQVMsRUFBRUEsK0VBQWY7QUFBdUMsaUJBQU8sRUFBRUYsVUFBaEQ7QUFBQSxrQ0FDRTtBQUFJLHFCQUFTLEVBQUVFLCtFQUFmO0FBQUEsbUNBQ0UsOERBQUMsa0RBQUQ7QUFBTSxrQkFBSSxFQUFDLEdBQVg7QUFBZSx1QkFBUyxFQUFFQSwwRUFBMUI7QUFBQSxxQ0FBNkM7QUFBQSx1Q0FDN0M7QUFBSyxxQkFBRyxFQUFDLFlBQVQ7QUFBc0IsMkJBQVMsRUFBRUEsOEVBQXFCTztBQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRDZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREYsRUFRR04sdURBQUEsQ0FBZSxVQUFDQyxJQUFELEVBQU9DLEtBQVAsRUFBaUI7QUFDL0IsZ0NBQ0U7QUFBZ0IsdUJBQVMsRUFBRUgsMEVBQTNCO0FBQUEscUNBQ0UsOERBQUMsa0RBQUQ7QUFBTSxvQkFBSSxFQUFFRSxJQUFJLENBQUNFLElBQWpCO0FBQUEsdUNBQXVCO0FBQUEsNkJBQ3BCRixJQUFJLENBQUNHLElBRGUsZUFFckI7QUFBTSw2QkFBUyxFQUFFTCx3RUFBakI7QUFBQSw4QkFBbUNFLElBQUksQ0FBQ0k7QUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGcUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixlQUFTSCxLQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREY7QUFRRCxXQVRBLENBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERixtQkFERjtBQStDRDs7R0FwRE1WLE07O0tBQUFBLE07QUFzRFAsK0RBQWVBLE1BQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvX2FwcC5hYjg3YTYyYTU0YTAxNzcyMzAwYi5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG5hdnN0eWxlcyBmcm9tICcuLi9zdHlsZXMvTmF2YmFyLm1vZHVsZS5jc3MnO1xyXG5pbXBvcnQgKiBhcyBGYUljb25zIGZyb20gJ3JlYWN0LWljb25zL2ZhJztcclxuaW1wb3J0ICogYXMgQWlJY29ucyBmcm9tICdyZWFjdC1pY29ucy9haSc7XHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBJY29uQ29udGV4dCB9IGZyb20gJ3JlYWN0LWljb25zJztcclxuaW1wb3J0IHsgTmF2YmFyRGF0YSB9IGZyb20gJy4vTmF2YmFyRGF0YSc7XHJcbmltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluaydcclxuXHJcblxyXG5mdW5jdGlvbiBOYXZiYXIoe2NoaWxkcmVufSkge1xyXG4gICAgY29uc3QgW25hdmJhciwgc2V0bmF2YmFyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBcclxuICAgIGNvbnN0IHNob3duYXZiYXIgPSAoKSA9PiBzZXRuYXZiYXIoIW5hdmJhcik7XHJcbiAgXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8PlxyXG4gICAgICAgIDxJY29uQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17eyBjb2xvcjogJyNmZmYnIH19PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e25hdnN0eWxlcy5uYXZiYXJ9PlxyXG4gICAgICAgICAgICA8TGluayBocmVmPScjJyBjbGFzc05hbWU9e25hdnN0eWxlcy5tZW51YmFyfT5cclxuICAgICAgICAgICAgICAgIDxhPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPGltZyBzcmM9Jy9tZW51LnN2ZycgY2xhc3NOYW1lPXtuYXZzdHlsZXMubWVudWJ1dHRvbn0gb25DbGljaz17c2hvd25hdmJhcn0vPlxyXG4gICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nbmF2cyc+XHJcbiAgICAgICAgICB7TmF2YmFyRGF0YS5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPXtpdGVtLnBhdGh9PjxhPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uaWNvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17bmF2c3R5bGVzLnRpdGxlfT57aXRlbS50aXRsZX08L3NwYW4+PC9hPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8bmF2IGNsYXNzTmFtZT17bmF2YmFyID8gYCR7bmF2c3R5bGVzLm5hdm1lbnV9ICR7bmF2c3R5bGVzLmFjdGl2ZX1gIDogbmF2c3R5bGVzLm5hdm1lbnV9PlxyXG4gICAgICAgICAgICA8dWwgY2xhc3NOYW1lPXtuYXZzdHlsZXMubmF2bWVudWl0ZW1zfSBvbkNsaWNrPXtzaG93bmF2YmFyfT5cclxuICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPXtuYXZzdHlsZXMubmFidmFydG9nZ2xlfT5cclxuICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9JyMnIGNsYXNzTmFtZT17bmF2c3R5bGVzLm1lbnViYXJ9PjxhPlxyXG4gICAgICAgICAgICAgICAgPGltZyBzcmM9Jy9jbG9zZS5zdmcnIGNsYXNzTmFtZT17bmF2c3R5bGVzLmNsb3NlYnV0dG9ufS8+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiA8QWlJY29ucy5BaU91dGxpbmVDbG9zZSAvPiAqL31cclxuICAgICAgICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgIDwvbGk+XHJcbiAgICAgICAgICAgICAge05hdmJhckRhdGEubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgPGxpIGtleT17aW5kZXh9IGNsYXNzTmFtZT17bmF2c3R5bGVzLm5hdnRleHR9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9e2l0ZW0ucGF0aH0+PGE+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5pY29ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtuYXZzdHlsZXMudGl0bGV9PntpdGVtLnRpdGxlfTwvc3Bhbj48L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgIDwvbmF2PlxyXG4gICAgICAgIDwvSWNvbkNvbnRleHQuUHJvdmlkZXI+XHJcbiAgICAgIDwvPlxyXG4gICAgKTtcclxuICB9XHJcbiAgXHJcbiAgZXhwb3J0IGRlZmF1bHQgTmF2YmFyO1xyXG4gIFxyXG4iXSwic291cmNlUm9vdCI6IiJ9