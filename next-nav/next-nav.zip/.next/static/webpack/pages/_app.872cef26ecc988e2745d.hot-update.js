self["webpackHotUpdate_N_E"]("pages/_app",{

/***/ "./components/Navbar.js":
/*!******************************!*\
  !*** ./components/Navbar.js ***!
  \******************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../styles/Navbar.module.css */ "./styles/Navbar.module.css");
/* harmony import */ var _styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons */ "./node_modules/react-icons/lib/esm/index.js");
/* harmony import */ var _NavbarData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./NavbarData */ "./components/NavbarData.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "D:\\Code_Practice\\NextJS_Navbar\\next-nav\\components\\Navbar.js",
    _s = $RefreshSig$();









function Navbar(_ref) {
  _s();

  var _this = this;

  var children = _ref.children;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false),
      navbar = _useState[0],
      setnavbar = _useState[1];

  var shownavbar = function shownavbar() {
    return setnavbar(!navbar);
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_icons__WEBPACK_IMPORTED_MODULE_2__.IconContext.Provider, {
      value: {
        color: '#fff'
      },
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navbar),
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
          href: "#",
          className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubar),
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
              src: "/menu.svg",
              className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubutton),
              onClick: shownavbar
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 15
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 20,
            columnNumber: 17
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 11
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("div", {
        className: "fullNav"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 11
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("nav", {
        className: navbar ? "".concat((_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenu), " ").concat((_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().active)) : (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenu),
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("ul", {
          className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navmenuitems),
          onClick: shownavbar,
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
            className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().nabvartoggle),
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
              href: "#",
              className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().menubar),
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("img", {
                  src: "/close.svg",
                  className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().closebutton)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 33,
                  columnNumber: 17
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 32,
                columnNumber: 62
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 32,
              columnNumber: 17
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 31,
            columnNumber: 15
          }, this), _NavbarData__WEBPACK_IMPORTED_MODULE_3__.NavbarData.map(function (item, index) {
            return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("li", {
              className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().navtext),
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                href: item.path,
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("a", {
                  children: [item.icon, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)("span", {
                    className: (_styles_Navbar_module_css__WEBPACK_IMPORTED_MODULE_5___default().title),
                    children: item.title
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 43,
                    columnNumber: 23
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 41,
                  columnNumber: 44
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 41,
                columnNumber: 21
              }, _this)
            }, index, false, {
              fileName: _jsxFileName,
              lineNumber: 40,
              columnNumber: 19
            }, _this);
          })]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 13
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 9
    }, this)
  }, void 0, false);
}

_s(Navbar, "hHN1UjZU2KVtXsET36Ln8CXJx+w=");

_c = Navbar;
/* harmony default export */ __webpack_exports__["default"] = (Navbar);

var _c;

$RefreshReg$(_c, "Navbar");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9OYXZiYXIuanMiXSwibmFtZXMiOlsiTmF2YmFyIiwiY2hpbGRyZW4iLCJ1c2VTdGF0ZSIsIm5hdmJhciIsInNldG5hdmJhciIsInNob3duYXZiYXIiLCJjb2xvciIsIm5hdnN0eWxlcyIsImNsb3NlYnV0dG9uIiwiTmF2YmFyRGF0YSIsIml0ZW0iLCJpbmRleCIsInBhdGgiLCJpY29uIiwidGl0bGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBLFNBQVNBLE1BQVQsT0FBNEI7QUFBQTs7QUFBQTs7QUFBQSxNQUFYQyxRQUFXLFFBQVhBLFFBQVc7O0FBQUEsa0JBQ0lDLCtDQUFRLENBQUMsS0FBRCxDQURaO0FBQUEsTUFDakJDLE1BRGlCO0FBQUEsTUFDVEMsU0FEUzs7QUFHeEIsTUFBTUMsVUFBVSxHQUFHLFNBQWJBLFVBQWE7QUFBQSxXQUFNRCxTQUFTLENBQUMsQ0FBQ0QsTUFBRixDQUFmO0FBQUEsR0FBbkI7O0FBRUEsc0JBQ0U7QUFBQSwyQkFDRSw4REFBQyw2REFBRDtBQUFzQixXQUFLLEVBQUU7QUFBRUcsYUFBSyxFQUFFO0FBQVQsT0FBN0I7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUVDLHlFQUFoQjtBQUFBLCtCQUNFLDhEQUFDLGtEQUFEO0FBQU0sY0FBSSxFQUFDLEdBQVg7QUFBZSxtQkFBUyxFQUFFQSwwRUFBMUI7QUFBQSxpQ0FDSTtBQUFBLG1DQUVGO0FBQUssaUJBQUcsRUFBQyxXQUFUO0FBQXFCLHVCQUFTLEVBQUVBLDZFQUFoQztBQUFzRCxxQkFBTyxFQUFFRjtBQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsZUFTRTtBQUFLLGlCQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVEYsZUFZRTtBQUFLLGlCQUFTLEVBQUVGLE1BQU0sYUFBTUksMEVBQU4sY0FBMkJBLHlFQUEzQixJQUFnREEsMEVBQXRFO0FBQUEsK0JBQ0U7QUFBSSxtQkFBUyxFQUFFQSwrRUFBZjtBQUF1QyxpQkFBTyxFQUFFRixVQUFoRDtBQUFBLGtDQUNFO0FBQUkscUJBQVMsRUFBRUUsK0VBQWY7QUFBQSxtQ0FDRSw4REFBQyxrREFBRDtBQUFNLGtCQUFJLEVBQUMsR0FBWDtBQUFlLHVCQUFTLEVBQUVBLDBFQUExQjtBQUFBLHFDQUE2QztBQUFBLHVDQUM3QztBQUFLLHFCQUFHLEVBQUMsWUFBVDtBQUFzQiwyQkFBUyxFQUFFQSw4RUFBcUJDO0FBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFENkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFERixFQVFHQyx1REFBQSxDQUFlLFVBQUNDLElBQUQsRUFBT0MsS0FBUCxFQUFpQjtBQUMvQixnQ0FDRTtBQUFnQix1QkFBUyxFQUFFSiwwRUFBM0I7QUFBQSxxQ0FDRSw4REFBQyxrREFBRDtBQUFNLG9CQUFJLEVBQUVHLElBQUksQ0FBQ0UsSUFBakI7QUFBQSx1Q0FBdUI7QUFBQSw2QkFDcEJGLElBQUksQ0FBQ0csSUFEZSxlQUVyQjtBQUFNLDZCQUFTLEVBQUVOLHdFQUFqQjtBQUFBLDhCQUFtQ0csSUFBSSxDQUFDSTtBQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUZxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGLGVBQVNILEtBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERjtBQVFELFdBVEEsQ0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREYsbUJBREY7QUFzQ0Q7O0dBM0NNWCxNOztLQUFBQSxNO0FBNkNQLCtEQUFlQSxNQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL19hcHAuODcyY2VmMjZlY2M5ODhlMjc0NWQuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBuYXZzdHlsZXMgZnJvbSAnLi4vc3R5bGVzL05hdmJhci5tb2R1bGUuY3NzJztcclxuaW1wb3J0ICogYXMgRmFJY29ucyBmcm9tICdyZWFjdC1pY29ucy9mYSc7XHJcbmltcG9ydCAqIGFzIEFpSWNvbnMgZnJvbSAncmVhY3QtaWNvbnMvYWknO1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgSWNvbkNvbnRleHQgfSBmcm9tICdyZWFjdC1pY29ucyc7XHJcbmltcG9ydCB7IE5hdmJhckRhdGEgfSBmcm9tICcuL05hdmJhckRhdGEnO1xyXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnXHJcblxyXG5cclxuZnVuY3Rpb24gTmF2YmFyKHtjaGlsZHJlbn0pIHtcclxuICAgIGNvbnN0IFtuYXZiYXIsIHNldG5hdmJhcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgXHJcbiAgICBjb25zdCBzaG93bmF2YmFyID0gKCkgPT4gc2V0bmF2YmFyKCFuYXZiYXIpO1xyXG4gIFxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPD5cclxuICAgICAgICA8SWNvbkNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3sgY29sb3I6ICcjZmZmJyB9fT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtuYXZzdHlsZXMubmF2YmFyfT5cclxuICAgICAgICAgICAgPExpbmsgaHJlZj0nIycgY2xhc3NOYW1lPXtuYXZzdHlsZXMubWVudWJhcn0+XHJcbiAgICAgICAgICAgICAgICA8YT5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIDxpbWcgc3JjPScvbWVudS5zdmcnIGNsYXNzTmFtZT17bmF2c3R5bGVzLm1lbnVidXR0b259IG9uQ2xpY2s9e3Nob3duYXZiYXJ9Lz5cclxuICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2Z1bGxOYXYnPlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPG5hdiBjbGFzc05hbWU9e25hdmJhciA/IGAke25hdnN0eWxlcy5uYXZtZW51fSAke25hdnN0eWxlcy5hY3RpdmV9YCA6IG5hdnN0eWxlcy5uYXZtZW51fT5cclxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT17bmF2c3R5bGVzLm5hdm1lbnVpdGVtc30gb25DbGljaz17c2hvd25hdmJhcn0+XHJcbiAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT17bmF2c3R5bGVzLm5hYnZhcnRvZ2dsZX0+XHJcbiAgICAgICAgICAgICAgICA8TGluayBocmVmPScjJyBjbGFzc05hbWU9e25hdnN0eWxlcy5tZW51YmFyfT48YT5cclxuICAgICAgICAgICAgICAgIDxpbWcgc3JjPScvY2xvc2Uuc3ZnJyBjbGFzc05hbWU9e25hdnN0eWxlcy5jbG9zZWJ1dHRvbn0vPlxyXG4gICAgICAgICAgICAgICAgICB7LyogPEFpSWNvbnMuQWlPdXRsaW5lQ2xvc2UgLz4gKi99XHJcbiAgICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgIHtOYXZiYXJEYXRhLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgIDxsaSBrZXk9e2luZGV4fSBjbGFzc05hbWU9e25hdnN0eWxlcy5uYXZ0ZXh0fT5cclxuICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPXtpdGVtLnBhdGh9PjxhPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uaWNvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17bmF2c3R5bGVzLnRpdGxlfT57aXRlbS50aXRsZX08L3NwYW4+PC9hPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgIDwvdWw+XHJcbiAgICAgICAgICA8L25hdj5cclxuICAgICAgICA8L0ljb25Db250ZXh0LlByb3ZpZGVyPlxyXG4gICAgICA8Lz5cclxuICAgICk7XHJcbiAgfVxyXG4gIFxyXG4gIGV4cG9ydCBkZWZhdWx0IE5hdmJhcjtcclxuICBcclxuIl0sInNvdXJjZVJvb3QiOiIifQ==